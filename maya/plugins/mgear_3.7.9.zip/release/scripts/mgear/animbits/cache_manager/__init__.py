""" ANIMATION CACHE MANAGER

mGear's animation cache manager is a tool that allows generating a Alembic GPU
cache representation of references rigs inside Autodesk Maya.

:module: mgear.animbits.cache_manager.__init__
"""

__version__ = 1.0
