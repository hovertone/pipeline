import difflib
import re
def twoStrings(strings):
    pass
